package com.akatsuki.flashcard;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Menyimpan berkas teks (cadangan, CSV, deck) ke folder Download/Akatsuki lewat MediaStore. */
@CapacitorPlugin(name = "AkatsukiFiles")
public class AkatsukiFilesPlugin extends Plugin {

    @PluginMethod
    public void saveToDownloads(PluginCall call) {
        String name = call.getString("filename");
        String data = call.getString("data");
        if (name == null || name.isEmpty() || data == null) {
            call.reject("Nama berkas atau isinya kosong.");
            return;
        }
        name = name.replace("/", "_").replace("\\", "_");
        byte[] bytes = data.getBytes(StandardCharsets.UTF_8);
        String low = name.toLowerCase(Locale.ROOT);
        String mime = low.endsWith(".json") ? "application/json" : low.endsWith(".csv") ? "text/csv" : "text/plain";
        try {
            JSObject ret = new JSObject();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = getContext().getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                values.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Akatsuki");
                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) { call.reject("Gagal membuat berkas di folder Download."); return; }
                try (OutputStream os = resolver.openOutputStream(uri)) {
                    if (os == null) { call.reject("Gagal membuka berkas untuk ditulis."); return; }
                    os.write(bytes);
                }
                ret.put("uri", uri.toString());
                ret.put("path", "Download/Akatsuki/" + name);
            } else {
                // Android 9 ke bawah: folder milik aplikasi (tanpa izin tambahan)
                File dir = getContext().getExternalFilesDir("Akatsuki");
                if (dir == null || (!dir.exists() && !dir.mkdirs())) { call.reject("Penyimpanan tidak tersedia."); return; }
                try (FileOutputStream os = new FileOutputStream(new File(dir, name))) { os.write(bytes); }
                ret.put("path", "Android/data/" + getContext().getPackageName() + "/files/Akatsuki/" + name);
            }
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "Gagal menyimpan berkas.");
        }
    }
}
