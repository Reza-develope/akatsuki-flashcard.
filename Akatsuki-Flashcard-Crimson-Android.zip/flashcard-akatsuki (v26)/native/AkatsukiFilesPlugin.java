package __PKG__;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import androidx.activity.result.ActivityResult;
import androidx.core.content.FileProvider;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Simpan berkas (cadangan progres) ke HP. Alur: stage (isi dititipkan ke berkas sementara, per potongan)
 * lalu saveAs (dialog "Simpan sebagai") atau share (menu Bagikan).
 * Isi cadangan TIDAK ikut dalam panggilan yang menunggu hasil dialog. Bila Android mematikan/memuat ulang aplikasi saat dialog
 * terbuka, penyalinan tetap selesai: yang dibutuhkan hanya berkas sementara + nama yang dicatat di SharedPreferences.
 */
@CapacitorPlugin(name = "AkatsukiFiles")
public class AkatsukiFilesPlugin extends Plugin {
    private static final String PREFS = "akatsuki_files";

    private File dir() {
        File d = new File(getContext().getCacheDir(), "akatsuki-backup");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    private File staged(String name) {
        return new File(dir(), name.replaceAll("[^A-Za-z0-9._-]", "_").replaceAll("^\\.+", "_"));
    }

    private String mimeOf(String name) {
        String low = name.toLowerCase(Locale.ROOT);
        return low.endsWith(".json") ? "application/json" : low.endsWith(".csv") ? "text/csv" : "text/plain";
    }

    @PluginMethod
    public void stage(PluginCall call) {
        String name = call.getString("filename"), chunk = call.getString("data");
        Integer index = call.getInt("index", 0);
        if (name == null || name.isEmpty() || chunk == null || chunk.isEmpty()) { call.reject("Isi berkas kosong."); return; }
        try (FileOutputStream os = new FileOutputStream(staged(name), index != null && index > 0)) {
            os.write(chunk.getBytes(StandardCharsets.UTF_8));
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "Gagal menyiapkan berkas.");
        }
    }

    @PluginMethod
    public void saveAs(PluginCall call) {
        String name = call.getString("filename");
        if (name == null || name.isEmpty()) { call.reject("Nama berkas kosong."); return; }
        File f = staged(name);
        if (!f.exists() || f.length() == 0) { call.reject("Isi berkas belum siap. Coba lagi."); return; }
        String shownName = name.replace("/", "_").replace("\\", "_");
        getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("file", f.getName()).putString("name", shownName).commit();
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mimeOf(name));
        intent.putExtra(Intent.EXTRA_TITLE, shownName);
        try {
            startActivityForResult(call, intent, "saveAsResult");
        } catch (Exception e) {
            call.reject("Dialog simpan tidak tersedia di perangkat ini.");
        }
    }

    @ActivityCallback
    private void saveAsResult(PluginCall call, ActivityResult result) {
        SharedPreferences sp = getContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String fileName = sp.getString("file", null), shown = sp.getString("name", "cadangan");
        Intent data = result.getData();
        Uri uri = data == null ? null : data.getData();
        if (result.getResultCode() != Activity.RESULT_OK || uri == null) {
            sp.edit().clear().commit();
            if (call != null) { JSObject cancelled = new JSObject(); cancelled.put("cancelled", true); call.resolve(cancelled); }
            return;
        }
        File f = fileName == null ? null : new File(dir(), fileName);
        if (f == null || !f.exists() || f.length() == 0) {
            if (call != null) call.reject("Isi berkas tidak ditemukan. Coba cadangkan lagi.");
            return;
        }
        try {
            long total = 0;
            try (InputStream in = new FileInputStream(f); OutputStream os = getContext().getContentResolver().openOutputStream(uri, "wt")) {
                if (os == null) throw new IOException("Gagal membuka berkas tujuan.");
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) { os.write(buf, 0, n); total += n; }
                os.flush();
            }
            String disp = shown;
            try (Cursor c = getContext().getContentResolver().query(uri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
                if (c != null && c.moveToFirst() && !c.isNull(0)) disp = c.getString(0);
            } catch (Exception ignored) { }
            f.delete();
            sp.edit().clear().commit();
            if (call != null) {
                JSObject ret = new JSObject();
                ret.put("uri", uri.toString());
                ret.put("name", disp);
                ret.put("bytes", total);
                call.resolve(ret);
            }
        } catch (Exception e) {
            if (call != null) call.reject(e.getMessage() != null ? e.getMessage() : "Gagal menyimpan berkas.");
        }
    }

    /** Menu Bagikan Android (Drive, Telegram, WhatsApp, dll.). Tidak menunggu hasil, jadi tidak terpengaruh aplikasi dimuat ulang. */
    @PluginMethod
    public void share(PluginCall call) {
        String name = call.getString("filename");
        if (name == null || name.isEmpty()) { call.reject("Nama berkas kosong."); return; }
        File f = staged(name);
        if (!f.exists() || f.length() == 0) { call.reject("Isi berkas belum siap. Coba lagi."); return; }
        try {
            Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", f);
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType(mimeOf(name));
            send.putExtra(Intent.EXTRA_STREAM, uri);
            send.setClipData(ClipData.newRawUri(f.getName(), uri));
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, "Bagikan cadangan");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "Menu bagikan tidak tersedia.");
        }
    }
}
