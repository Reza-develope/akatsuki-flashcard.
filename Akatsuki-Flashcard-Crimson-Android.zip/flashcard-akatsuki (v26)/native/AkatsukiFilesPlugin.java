package __PKG__;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/** Dialog "Simpan sebagai" bawaan Android (Storage Access Framework): pengguna memilih sendiri folder dan nama berkas. Tanpa izin penyimpanan. */
@CapacitorPlugin(name = "AkatsukiFiles")
public class AkatsukiFilesPlugin extends Plugin {

    @PluginMethod
    public void saveAs(PluginCall call) {
        String name = call.getString("filename");
        String data = call.getString("data");
        if (name == null || name.isEmpty() || data == null) {
            call.reject("Nama berkas atau isinya kosong.");
            return;
        }
        name = name.replace("/", "_").replace("\\", "_");
        String low = name.toLowerCase(Locale.ROOT);
        String mime = low.endsWith(".json") ? "application/json" : low.endsWith(".csv") ? "text/csv" : "text/plain";
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mime);
        intent.putExtra(Intent.EXTRA_TITLE, name);
        try {
            startActivityForResult(call, intent, "saveAsResult");
        } catch (Exception e) {
            call.reject("Dialog simpan tidak tersedia di perangkat ini.");
        }
    }

    @ActivityCallback
    private void saveAsResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent resultData = result.getData();
        if (result.getResultCode() != Activity.RESULT_OK || resultData == null || resultData.getData() == null) {
            JSObject cancelled = new JSObject();
            cancelled.put("cancelled", true);
            call.resolve(cancelled);
            return;
        }
        Uri uri = resultData.getData();
        try {
            byte[] bytes = call.getString("data", "").getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = getContext().getContentResolver().openOutputStream(uri, "wt")) {
                if (os == null) { call.reject("Gagal membuka berkas untuk ditulis."); return; }
                os.write(bytes);
            }
            String shown = call.getString("filename", "cadangan");
            try (Cursor c = getContext().getContentResolver().query(uri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
                if (c != null && c.moveToFirst() && !c.isNull(0)) shown = c.getString(0);
            } catch (Exception ignored) { }
            JSObject ret = new JSObject();
            ret.put("uri", uri.toString());
            ret.put("name", shown);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject(e.getMessage() != null ? e.getMessage() : "Gagal menyimpan berkas.");
        }
    }
}
