# Akatsuki Flashcard — Crimson Android Assets

This package includes the existing Akatsuki Flashcard v26 project with a new
Japanese Crimson Night visual identity.

## New assets
- `assets/icon-only.png` — 1024×1024 app icon
- `assets/icon-foreground.png` and `assets/icon-background.png` — Android adaptive icon layers
- `assets/splash.png` and `assets/splash-dark.png` — 2732×2732 splash artwork
- `assets/icons/*` — updated PWA icon sizes
- `assets/icon.svg` — updated favicon

## Build
Install dependencies, build the web bundle, add the Android platform, generate
native resources, sync Capacitor, then build the APK:

```bash
npm install
npm run build:web
npx cap add android
npx capacitor-assets generate --android
npx cap sync android
cd android
./gradlew assembleDebug
```

Android 12 and newer use the system splash screen layout, which centers the app
branding icon on a background; older Android versions can show the generated
splash artwork more fully.

## Update v2 (APK)
- Ikon: logo bulan sabit merah (`icon-only`, `icon-foreground`, `icon-background` putih) dipas ke safe zone adaptive icon.
- Splash native (`splash*.png`) & loading in-app (`assets/boot-cat.jpg` + teks ちょっと待ってください) memakai gambar kucing.
- `css/apk.css`: penyesuaian ukuran HP, notch, landscape, tablet.
