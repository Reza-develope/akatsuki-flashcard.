// Memasang plugin native "AkatsukiFiles" (Simpan sebagai) ke proyek Android hasil `cap add android`.
// Dijalankan otomatis oleh hook "capacitor:sync:before" (package.json) dan aman dijalankan berulang.
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..');
const javaRoot = path.join(root, 'android', 'app', 'src', 'main', 'java');
if (!fs.existsSync(javaRoot)) { console.log('[native] folder android belum ada, dilewati'); process.exit(0); }
function find(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { const r = find(p); if (r) return r; }
    else if (e.name === 'MainActivity.java') return p;
  }
  return null;
}
const main = find(javaRoot);
if (!main) { console.error('[native] MainActivity.java tidak ditemukan'); process.exit(1); }
const pkg = (fs.readFileSync(main, 'utf8').match(/^\s*package\s+([\w.]+)\s*;/m) || [])[1];
if (!pkg) { console.error('[native] package MainActivity tidak terbaca'); process.exit(1); }
const dir = path.dirname(main);
for (const f of ['AkatsukiFilesPlugin.java', 'MainActivity.java']) {
  fs.writeFileSync(path.join(dir, f), fs.readFileSync(path.join(root, 'native', f), 'utf8').replace(/__PKG__/g, pkg));
}
console.log('[native] plugin AkatsukiFiles terpasang di ' + pkg);

// FileProvider harus mencakup folder cache (dipakai menu "Bagikan").
const xml = path.join(root, 'android', 'app', 'src', 'main', 'res', 'xml', 'file_paths.xml');
if (fs.existsSync(xml)) {
  const x = fs.readFileSync(xml, 'utf8');
  if (!/<cache-path/.test(x)) fs.writeFileSync(xml, x.replace('</paths>', '    <cache-path name="my_cache_images" path="." />\n</paths>'));
}
// Tanda tangan debug TETAP: build GitHub biasanya membuat kunci acak tiap run, sehingga APK baru tidak bisa menimpa yang lama
// (harus uninstall = progres hilang). Dengan kunci tetap di native/akatsuki-debug.keystore, update berikutnya menimpa tanpa uninstall.
const gradle = path.join(root, 'android', 'app', 'build.gradle');
if (fs.existsSync(gradle)) {
  const g = fs.readFileSync(gradle, 'utf8');
  if (!g.includes('akatsuki-debug.keystore')) {
    const block = "android {\n    signingConfigs {\n        debug {\n            storeFile rootProject.file('../native/akatsuki-debug.keystore')\n            storePassword 'android'\n            keyAlias 'androiddebugkey'\n            keyPassword 'android'\n            storeType 'pkcs12'\n        }\n    }";
    const g2 = g.replace(/^android\s*\{/m, block);
    if (g2 === g) console.error('[native] blok "android {" tidak ditemukan di build.gradle; tanda tangan tetap dilewati');
    else { fs.writeFileSync(gradle, g2); console.log('[native] tanda tangan debug tetap dipasang'); }
  }
}
