// Memasang plugin native "AkatsukiFiles" (Simpan sebagai) ke proyek Android hasil `cap add android`.
// Dijalankan otomatis oleh hook "capacitor:sync:before" (package.json) dan aman dijalankan berulang.
const fs = require('fs'), path = require('path');
const root = path.resolve(__dirname, '..');
const javaRoot = path.join(root, 'android', 'app', 'src', 'main', 'java');
if (!fs.existsSync(javaRoot)) { console.log('[native] folder android belum ada, dilewati'); process.exit(0); }
function find(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { const r = find(p); if (r) return r; }
    else if (e.name === 'MainActivity.java') return p;
  }
  return null;
}
const main = find(javaRoot);
if (!main) { console.error('[native] MainActivity.java tidak ditemukan'); process.exit(1); }
const pkg = (fs.readFileSync(main, 'utf8').match(/^\s*package\s+([\w.]+)\s*;/m) || [])[1];
if (!pkg) { console.error('[native] package MainActivity tidak terbaca'); process.exit(1); }
const dir = path.dirname(main);
for (const f of ['AkatsukiFilesPlugin.java', 'MainActivity.java']) {
  fs.writeFileSync(path.join(dir, f), fs.readFileSync(path.join(root, 'native', f), 'utf8').replace(/__PKG__/g, pkg));
}
console.log('[native] plugin AkatsukiFiles terpasang di ' + pkg);
