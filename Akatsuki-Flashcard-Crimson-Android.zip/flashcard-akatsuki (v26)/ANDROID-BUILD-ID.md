# Akatsuki Flashcard — Android build

Proyek ini membungkus aplikasi web Akatsuki Flashcard v26 menggunakan Capacitor 7.

## Build APK lewat GitHub Actions (bisa dilakukan dari HP)

1. Buat repository GitHub baru, misalnya `akatsuki-flashcard`.
2. Upload seluruh isi folder proyek ini ke repository (jangan upload folder `node_modules`, `www`, atau `android` jika sudah ada dari build sebelumnya).
3. Pastikan file `.github/workflows/build-apk.yml` ikut ter-upload.
4. Buka tab **Actions** pada repository. Jika diminta, pilih **I understand my workflows, go ahead and enable them**.
5. Pilih workflow **Build Akatsuki APK**, tekan **Run workflow**.
6. Tunggu sampai workflow berstatus hijau. Buka hasil run, lalu unduh artifact **Akatsuki-Flashcard-debug-APK**.
7. Ekstrak ZIP artifact dan instal `app-debug.apk` di Android.

Setiap push ke branch `main` juga otomatis menjalankan build.

## Build lokal (opsional)

Memerlukan Node.js 20+, Java 21, Android SDK, dan Android platform tools.

```bash
npm install
npm run build:web
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK debug akan berada di `android/app/build/outputs/apk/debug/app-debug.apk`.

## Catatan

- APK debug cocok untuk instalasi dan pengujian pribadi; belum ditandatangani sebagai rilis distribusi Play Store.
- Progres flashcard disimpan oleh aplikasi web di penyimpanan lokal WebView/IndexedDB. Data dari browser/PWA lama tidak otomatis berpindah ke APK. Gunakan fitur cadangan/restore di aplikasi untuk memindahkan progres jika diperlukan.
- Aplikasi tetap memuat Google Fonts dari internet; fitur font tersebut dapat kembali ke font sistem saat offline.
- Jangan mengubah `appId` setelah APK dipakai menyimpan progres, karena Android akan menganggapnya aplikasi berbeda.
